<?php

namespace WPPayForm\App;

use WPPayForm\Framework\Foundation\App as AppFacade;

class App extends AppFacade
{
    // ...
}
