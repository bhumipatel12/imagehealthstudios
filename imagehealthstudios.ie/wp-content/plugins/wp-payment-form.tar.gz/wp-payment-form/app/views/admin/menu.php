<?php do_action('wppayform_global_menu'); ?>
<div id='wppayforms_app'>
    Loading App...
</div>
