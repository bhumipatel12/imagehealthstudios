<div class="wpf_submission_header">
    <div class="wpf_submission_message">
        <?php echo $header_content; ?>
    </div>
</div>