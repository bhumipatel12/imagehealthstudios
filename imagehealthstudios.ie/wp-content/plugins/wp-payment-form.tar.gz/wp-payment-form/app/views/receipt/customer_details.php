<div class="wpf_customer_details">
    <h4><?php _e('Submission Details', 'wppayform'); ?></h4>
    <div class="wpf_submission_details">
        <?php echo $submission_details; ?>
    </div>
</div>