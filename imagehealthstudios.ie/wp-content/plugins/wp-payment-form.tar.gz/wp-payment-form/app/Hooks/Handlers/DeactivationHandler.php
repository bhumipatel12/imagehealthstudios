<?php

namespace WPPayForm\App\Hooks\Handlers;

class DeactivationHandler
{
    public function handle()
    {
        // ...
    }
}
