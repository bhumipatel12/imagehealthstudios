import ModulaDivi from './ModulaDivi/ModulaDivi';

export default [ModulaDivi];
