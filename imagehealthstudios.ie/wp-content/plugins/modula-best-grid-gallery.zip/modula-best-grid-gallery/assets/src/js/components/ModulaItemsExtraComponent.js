export const ModulaItemsExtraComponent = ( props ) => {

    return null;
}

export default wp.components.withFilters( 'modula.ModulaItemsExtraComponent')(ModulaItemsExtraComponent);